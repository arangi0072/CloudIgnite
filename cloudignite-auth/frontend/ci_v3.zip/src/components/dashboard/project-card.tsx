import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal } from 'lucide-react';
import type { Project } from '@/app/dashboard/projects-data';
import { Button } from '../ui/button';
import Link from 'next/link';

export default function ProjectCard({ project }: { project: Project }) {
  return (
    <Link href={`/dashboard/${project.name}`}>
        <Card className="group h-full overflow-hidden border-border/50 bg-card transition-all hover:-translate-y-1 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/10">
        <CardHeader className="flex flex-row items-start justify-between space-y-0">
            <div className="space-y-1">
                <CardTitle className="font-medium text-foreground">{project.name}</CardTitle>
                <div className="flex items-center gap-2">
                    <span className="inline-block rounded-full bg-green-400/20 px-2 py-0.5 text-xs text-green-300">
                        {project.environment}
                    </span>
                    <span className="text-xs text-muted-foreground">{project.region}</span>
                </div>
            </div>
            <Button variant="ghost" size="icon" className="h-6 w-6">
                <MoreHorizontal className="h-4 w-4" />
            </Button>
        </CardHeader>
        <CardContent className="flex items-end justify-between pt-2">
            <div className="flex items-center gap-2 text-muted-foreground">
                {project.services.map(service => (
                    <service.icon key={service.name} className="h-5 w-5" title={service.name}/>
                ))}
            </div>
            <div className="text-xs text-muted-foreground">
                Updated {project.lastUpdated}
            </div>
        </CardContent>
        </Card>
    </Link>
  );
}
