'use client';

import { useState } from 'react';
import PageHeader from "@/components/dashboard/page-header";
import { Button } from "@/components/ui/button";
import { Plus, LayoutGrid, List } from 'lucide-react';
import { projects } from './projects-data';
import ProjectCard from '@/components/dashboard/project-card';
import CreateProjectModal from '@/components/dashboard/create-project-modal';
import ProjectsEmptyState from '@/components/dashboard/projects-empty-state';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Link from 'next/link';

export default function DashboardProjectsPage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const hasProjects = projects.length > 0;

  return (
    <div className="space-y-8">
      <PageHeader
        title="Projects"
        description="Manage infrastructure across all your applications."
        action={{
            label: "Create Project",
            onClick: () => setIsModalOpen(true),
            icon: <Plus className="mr-2 h-4 w-4" />
        }}
      />
      
      {hasProjects ? (
        <>
            <div className="flex items-center justify-end gap-2">
                <Button variant={viewMode === 'grid' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('grid')}>
                    <LayoutGrid className="h-4 w-4" />
                </Button>
                <Button variant={viewMode === 'list' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('list')}>
                    <List className="h-4 w-4" />
                </Button>
            </div>
            {viewMode === 'grid' ? (
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {projects.map(p => <ProjectCard key={p.name} project={p} />)}
                </div>
            ) : (
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Project</TableHead>
                            <TableHead>Region</TableHead>
                            <TableHead>Environment</TableHead>
                            <TableHead>Services</TableHead>
                            <TableHead>Last Deploy</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {projects.map(p => (
                            <TableRow key={p.name}>
                                <TableCell>
                                    <Link href={`/dashboard/${p.name}`} className="font-medium text-primary hover:underline">{p.name}</Link>
                                </TableCell>
                                <TableCell>{p.region}</TableCell>
                                <TableCell>
                                    <span className="inline-block rounded-full bg-green-400/20 px-2 py-0.5 text-xs text-green-300">
                                        {p.environment}
                                    </span>
                                </TableCell>
                                <TableCell>
                                    <div className="flex items-center gap-2 text-muted-foreground">
                                        {p.services.map(s => <s.icon key={s.name} className="h-5 w-5" title={s.name} />)}
                                    </div>
                                </TableCell>
                                <TableCell>{p.lastUpdated}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            )}
        </>
      ) : (
        <ProjectsEmptyState onCreate={() => setIsModalOpen(true)} />
      )}
      
      <CreateProjectModal open={isModalOpen} onOpenChange={setIsModalOpen} />
    </div>
  );
}
