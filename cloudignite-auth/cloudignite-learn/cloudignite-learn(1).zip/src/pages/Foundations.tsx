import { useEffect } from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, BookOpen, Terminal
} from 'lucide-react';
import { CONCEPTS } from '../data/foundations';

function FoundationsHero() {
  return (
    <section className="relative min-h-[60vh] flex items-center pt-24 pb-12 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-black" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-slate-600/10 rounded-full blur-[120px] pointer-events-none" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <Link to="/" className="inline-flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm font-medium mb-12">
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </Link>
        
        <div className="max-w-3xl">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center shadow-xl text-white">
              <BookOpen className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-slate-400 font-bold uppercase tracking-widest text-sm">Learning Path</h2>
              <div className="text-slate-500 text-sm">Module 01</div>
            </div>
          </div>

          <h1 className="text-[50px] md:text-[70px] font-display font-black leading-[0.9] tracking-tight mb-8">
            ARCHITECTURE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-200 to-slate-500">
              FOUNDATIONS
            </span>
          </h1>

          <p className="text-xl text-slate-400 leading-relaxed">
            Master the core concepts of system design. From load balancers and caching to databases and microservices, these are the fundamental building blocks of internet-scale applications.
          </p>
        </div>
      </div>
    </section>
  )
}

function ConceptsGrid() {
  return (
    <section className="py-24 relative border-t border-white/5 bg-[#02040a]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CONCEPTS.map((concept, i) => (
            <Link to={`/foundations/${concept.id}`} key={concept.id} className="block group">
              <motion.div
                id={concept.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group relative bg-white/5 border border-white/10 rounded-3xl p-8 hover:bg-white/10 transition-colors overflow-hidden h-full"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-110" />
                
                <div className={`w-14 h-14 rounded-2xl ${concept.bg} ${concept.border} border flex items-center justify-center mb-6 shadow-xl relative z-10`}>
                  <concept.icon className={`w-7 h-7 ${concept.color}`} />
                </div>
                
                <h3 className="text-2xl font-black text-white mb-3 relative z-10 group-hover:text-indigo-400 transition-colors">{concept.title}</h3>
                <p className="text-sm text-slate-400 mb-8 leading-relaxed font-medium relative z-10">{concept.desc}</p>
                
                <div className="space-y-3 relative z-10 mb-6">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Key Topics</h4>
                  {concept.points.map((point, j) => (
                    <div key={j} className="flex items-center gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
                      <span className="text-xs text-slate-300 font-bold">{point}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 relative z-10 flex items-center justify-between">
                   <span className="text-xs font-bold text-slate-400 uppercase tracking-widest group-hover:text-indigo-400 transition-colors">Read More</span>
                   <Terminal className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

function CorePrinciples() {
  return (
    <section className="py-24 relative border-t border-white/5 bg-black">
      <div className="container mx-auto px-6 max-w-4xl">
        <div className="flex items-center gap-4 mb-4">
          <Terminal className="w-8 h-8 text-slate-400" />
          <h2 className="text-[30px] md:text-[40px] font-display font-black tracking-tight">DESIGN <span className="text-slate-400">PRINCIPLES</span></h2>
        </div>
        <p className="text-slate-400 text-lg mb-12">Universal rules for building robust systems.</p>

        <div className="space-y-6">
          {[
            { title: "Single Responsibility Principle", text: "Every service, class, or function should have exactly one reason to change. Decoupled systems are easier to scale and maintain." },
            { title: "Design for Failure", text: "Assume everything will fail. Servers will crash, networks will partition, and disks will die. Build redundancy, retries, and circuit breakers." },
            { title: "Statelessness over Stateful", text: "Whenever possible, make services stateless. Store session data in a distributed cache like Redis. Stateless services can scale horizontally instantly." },
            { title: "Optimize for the Bottleneck", text: "Identify whether your system is CPU-bound, Memory-bound, or I/O-bound. Premature optimization is the root of all evil; measure first." }
          ].map((principle, i) => (
            <div key={i} className="bg-[#02040a] border border-white/10 rounded-2xl p-6 md:p-8">
              <h3 className="text-xl font-bold text-white mb-3">{principle.title}</h3>
              <p className="text-slate-400 leading-relaxed text-sm md:text-base">{principle.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function CaseStudies() {
  return (
    <section className="py-32 relative border-t border-white/5 bg-[#03060E]">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto mb-20 text-center">
          <h2 className="text-4xl md:text-5xl font-display font-black tracking-tight mb-6 text-white">
            PRODUCTION <span className="text-cyan-400">CASE STUDIES</span>
          </h2>
          <p className="text-lg text-slate-400">
            Theory meets reality. See how the fundamental concepts of load balancing, caching, databases, and microservices are applied together in step-by-step architectural breakdowns of the world's most demanding platforms.
          </p>
        </div>

        <div className="space-y-24">
          {/* Netflix Case Study */}
          <div className="bg-[#0a0f1c] border border-white/10 rounded-3xl p-8 lg:p-12">
            <div className="flex flex-col lg:flex-row gap-12">
              <div className="lg:w-1/3">
                <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center mb-6">
                  <span className="text-red-500 font-bold text-2xl">N</span>
                </div>
                <h3 className="text-3xl font-black text-white mb-4">Netflix: Global Video Streaming</h3>
                <p className="text-slate-400 leading-relaxed mb-6">
                  Serving 15% of the world's internet bandwidth requires separating the Control Plane (AWS) from the Data Plane (Open Connect).
                </p>
                <Link to="/architecture/netflix" className="inline-flex items-center gap-2 text-red-400 font-bold hover:text-red-300 transition-colors uppercase tracking-widest text-sm">
                  Full Architecture <span>→</span>
                </Link>
              </div>
              <div className="lg:w-2/3 space-y-8">
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">1</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 1: The Client Request & DNS</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">When a user clicks "Play", the Netflix client contacts the Control Plane (hosted entirely on AWS). AWS load balancers intercept the request and route it to the Playback API, a microservice responsible for checking licensing, DRM, and evaluating exactly which video file format is needed.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">2</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 2: Steering Service & ISP Proximity</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">The Playback API consults the Steering Service to find the absolute best Open Connect Appliance (OCA) to stream from. Netflix installs its own custom hard-drives directly inside internet service providers (ISPs) worldwide. The Steering Service uses BGP routing data to find the OCA geographically and topologically closest to the user's IP.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">3</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 3: Direct Streaming bypassing the Internet</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">The AWS Control Plane hands the client a URL pointing directly to the selected OCA. The client begins streaming directly from the ISP node, keeping heavy video traffic entirely off the public internet backbone. This unique Data Plane separation ensures flawless playback free from general internet congestion.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">4</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 4: Proactive Caching (Predictive Pushing)</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">During off-peak hours (like 3 AM), Netflix's control plane uses machine learning to predict which shows will be popular in which regions tomorrow. They pre-copy the heavy video bytes to the local ISP boxes during the night so the network doesn't choke when everyone logs in at 7 PM.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Uber Case Study */}
          <div className="bg-[#0a0f1c] border border-white/10 rounded-3xl p-8 lg:p-12">
            <div className="flex flex-col lg:flex-row gap-12">
              <div className="lg:w-1/3">
                <div className="w-16 h-16 bg-slate-800 border border-slate-700 rounded-2xl flex items-center justify-center mb-6">
                  <span className="text-white font-bold text-2xl">U</span>
                </div>
                <h3 className="text-3xl font-black text-white mb-4">Uber: Real-Time Dispatch</h3>
                <p className="text-slate-400 leading-relaxed mb-6">
                  Handling millions of concurrent WebSockets, geospatial indexing, and real-time Kafka event streams to match riders with drivers in milliseconds.
                </p>
                <Link to="/architecture/uber" className="inline-flex items-center gap-2 text-slate-300 font-bold hover:text-white transition-colors uppercase tracking-widest text-sm">
                  Full Architecture <span>→</span>
                </Link>
              </div>
              <div className="lg:w-2/3 space-y-8">
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">1</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 1: The Firehose of Telemetry</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">Every active Uber driver emits their GPS coordinates via WebSockets every 4 seconds. This creates a relentless, massive stream of write operations. These connections are held entirely by the Dispatch servers, creating millions of open TCP connections that cannot simply drop if a server spikes.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">2</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 2: H3 Geospatial Indexing</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">Plotting millions of cars on an X/Y system is insanely slow for queries. Uber invented and open-sourced 'H3', a system that grids the earth into rigid hexagons. When a driver pings their location, Uber's tracking service instantly snaps their car into a specific Hexagon ID, caching the state in high-memory stores (Redis/Ringpop).</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">3</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 3: The Matchmaking Engine</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">When a rider requests a car, the Rider API looks up their current Hexagon ID. It asks the Dispatch service to supply all active drivers inside that exact Hexagon (and adjacent hexagons). Because it's matching simple Hexagon strings rather than performing costly Math/Distance equations on pure latitude/longitude, the query takes nearly zero milliseconds.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">4</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 4: Kafka Event Propagation</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">Once a match is made, the master system publishes a "Trip Created" event to Apache Kafka. Independent microservices (Billing, Analytics, ETA Tracking, Fraud Detection) consume this Kafka topic asynchronously without blocking the core driver-rider loop, allowing immense elasticity.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Discord Case Study */}
          <div className="bg-[#0a0f1c] border border-white/10 rounded-3xl p-8 lg:p-12">
            <div className="flex flex-col lg:flex-row gap-12">
              <div className="lg:w-1/3">
                <div className="w-16 h-16 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl flex items-center justify-center mb-6">
                  <span className="text-indigo-400 font-bold text-2xl">D</span>
                </div>
                <h3 className="text-3xl font-black text-white mb-4">Discord: Massive Scale Chat</h3>
                <p className="text-slate-400 leading-relaxed mb-6">
                  Stitching together millions of messages per second. Trillions of rows stored in Cassandra databases heavily optimized for sequential read speed.
                </p>
                <Link to="/architecture/discord" className="inline-flex items-center gap-2 text-indigo-400 font-bold hover:text-indigo-300 transition-colors uppercase tracking-widest text-sm">
                  Full Architecture <span>→</span>
                </Link>
              </div>
              <div className="lg:w-2/3 space-y-8">
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">1</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 1: Elixir & Erlang VM (BEAM)</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">Millions of gamers are connected concurrently to Voice and Text channels. Standard NodeJS/Python threads would crush under the context switching of this concurrency. Discord utilizes Elixir on the Erlang VM; a language specifically built to allow a single server to handle millions of incredibly lightweight processes with near-perfect isolation.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">2</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 2: Guild Brokers & Message Routing</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">When someone typing in a 100,000-person server sends a message, it cannot broadcast randomly. The message hits a Guild Broker ring that maps the Server ID to specific backend processors. This localized state tracking enables Discord to dispatch the exact message to only the connected users of that specific server rapidly without scanning all online accounts.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">3</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 3: Cassandra Storage Model</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">Discord's Read-to-Write ratio is approximately 50/50, and they store trillions of chat records. A Relational SQL database would completely buckle under the indexing writes. Cassandra's NoSQL wide-column format persists data almost completely sequentially on disk. By partitioning the database by `Channel ID` and sorting rows by `Timestamp`, loading the entire chat history for a massively scrolling user is merely a straight, linear disk read—blazing fast.</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold flex-shrink-0">4</div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-200 mb-2">Step 4: ScyllaDB & Tombstone Mitigation</h4>
                      <p className="text-slate-400 leading-relaxed text-sm">As Cassandra's Java Garbage Collection began causing unacceptable lag spikes when attempting to process billions of message edits & deletes (which create invisible NoSQL "tombstones"), Discord executed an impossibly huge live-migration to ScyllaDB. Written natively in C++, Scylla bypasses Java's GC pauses entirely and manages massive tombstone clusters seamlessly.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Foundations() {
  useEffect(() => {
    document.getElementById('scroll-container')?.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  return (
    <div className="bg-black text-slate-100 min-h-screen relative font-sans">
      <FoundationsHero />
      <ConceptsGrid />
      <CorePrinciples />
      
      <CaseStudies />

      <div className="py-12 border-t border-white/5 bg-black text-center text-slate-500 text-sm">
         Start by mastering the basics, then dive into the complex architectures.
      </div>
    </div>
  );
}
