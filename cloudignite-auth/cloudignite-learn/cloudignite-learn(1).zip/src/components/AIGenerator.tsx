import { motion } from 'motion/react';
import { Cpu, Terminal, Sparkles, CheckCircle2, Server, Database } from 'lucide-react';
import { useState } from 'react';

export function AIGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [prompt, setPrompt] = useState('Build scalable realtime chat application');

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => setIsGenerating(false), 3000);
  };

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          
          <div className="mb-12 text-center">
             <div className="inline-flex items-center gap-2 text-cyan-400 font-bold text-[10px] tracking-widest uppercase mb-4 bg-cyan-500/10 border border-cyan-500/20 px-3 py-1 rounded-full">
               <Sparkles className="w-3 h-3" />
               AI Architecture Blueprint
             </div>
             <h2 className="text-[40px] md:text-[50px] font-display font-black mb-6 leading-[0.9] tracking-tight">DESCRIBE IT. <span className="text-cyan-400">BUILD IT.</span></h2>
             <p className="text-slate-400 text-lg max-w-2xl mx-auto">
                Generate production-ready architecture diagrams, stack recommendations, and scaling strategies instantly from natural language.
             </p>
          </div>

          <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-2 relative overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
            {/* Command Line Input */}
            <div className="bg-[#02040a] border border-white/5 rounded-2xl p-6 lg:p-8 relative z-10">
               <div className="flex flex-col lg:flex-row gap-6 items-center">
                  <div className="flex-1 w-full bg-white/5 border border-white/10 rounded-xl p-4 flex items-center gap-4 focus-within:border-cyan-500/50 focus-within:bg-white/10 transition-all shadow-inner">
                     <Terminal className="w-6 h-6 text-cyan-500" />
                     <input 
                        type="text"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="w-full bg-transparent border-none outline-none text-slate-100 font-bold"
                        placeholder="Describe your system..."
                     />
                  </div>
                  <button 
                     onClick={handleGenerate}
                     disabled={isGenerating}
                     className="w-full lg:w-auto relative group overflow-hidden bg-white text-black px-8 py-4 rounded-xl font-black text-sm uppercase tracking-widest hover:bg-cyan-400 transition-colors flex items-center justify-center gap-2 disabled:opacity-80 disabled:hover:bg-white shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:shadow-[0_0_20px_rgba(34,211,238,0.4)]"
                  >
                     {isGenerating ? (
                       <span className="flex items-center gap-2">
                         <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                         GENERATING
                       </span>
                     ) : (
                       <span className="flex items-center gap-2">
                         <Cpu className="w-4 h-4" /> GENERATE
                       </span>
                     )}
                     <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/50 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] pointer-events-none" />
                  </button>
               </div>

               {/* Simulated Output Area */}
               <div className="mt-8 pt-8 border-t border-white/10">
                  <div className={`transition-all duration-1000 ${isGenerating ? 'opacity-50 blur-sm' : 'opacity-100'}`}>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                       
                       <div className="col-span-2 bg-[#02040a] border border-white/5 rounded-xl p-6 relative overflow-hidden group">
                          {/* Holographic grid */}
                          <div className="absolute inset-0 bg-grid-white opacity-[0.2]" />
                          <div className="absolute top-0 right-0 p-4">
                             <div className="text-[10px] font-bold text-cyan-500 bg-cyan-950/50 px-2 py-1 rounded tracking-widest uppercase">SYSTEM GENERATED</div>
                          </div>
                          
                          <h4 className="text-[10px] text-slate-400 mb-6 flex items-center gap-2 font-bold uppercase tracking-widest">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" /> Architecture Preview
                          </h4>
                          
                          {/* Fake architectural diagram */}
                          <div className="relative h-48 flex items-center justify-between px-8">
                             <div className="w-16 h-16 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center relative z-10 shadow-[0_0_15px_rgba(0,0,0,0.5)]">
                               Client
                             </div>
                             
                             <div className="flex-1 h-px bg-slate-700 relative">
                                <motion.div animate={{ x: ['-0%', '200%'] }} transition={{ duration: 2, repeat: Infinity, ease: 'linear'}} className="absolute top-1/2 -mt-1 w-2 h-2 bg-cyan-400 rounded-full blur-[2px]" />
                                <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-mono text-slate-500">WSS</div>
                             </div>
                             
                             <div className="w-20 h-24 rounded-xl bg-indigo-950 border border-indigo-500/30 flex items-center justify-center flex-col gap-2 relative z-10 glow-purple">
                               <Server className="w-6 h-6 text-indigo-400" />
                               <span className="text-[10px] font-mono">Gateway</span>
                             </div>

                             <div className="flex-1 h-px bg-slate-700 relative" />

                             <div className="flex flex-col gap-4 relative z-10">
                               <div className="w-20 h-16 rounded-xl bg-slate-800 border-l border-b border-rose-500/50 flex items-center justify-center flex-col gap-1">
                                 <Database className="w-4 h-4 text-rose-400" />
                                 <span className="text-[10px] font-mono">Redis</span>
                               </div>
                               <div className="w-20 h-16 rounded-xl bg-slate-800 border-l border-b border-orange-500/50 flex items-center justify-center flex-col gap-1">
                                 <Database className="w-4 h-4 text-orange-400" />
                                 <span className="text-[10px] font-mono">Postgres</span>
                               </div>
                             </div>
                          </div>
                       </div>

                       <div className="flex flex-col gap-4">
                          <div className="bg-[#02040a] border border-white/5 rounded-xl p-5 flex-1 shadow-inner">
                             <h4 className="text-[10px] font-bold text-slate-400 mb-4 uppercase tracking-widest">Tech Stack</h4>
                             <ul className="space-y-3">
                               {['Go (WebSocket Server)', 'Redis (Pub/Sub)', 'PostgreSQL (History)', 'React (Client)'].map((item) => (
                                 <li key={item} className="flex items-center gap-2 text-sm text-slate-200 font-bold">
                                   <CheckCircle2 className="w-4 h-4 text-cyan-400" /> {item}
                                 </li>
                               ))}
                             </ul>
                          </div>
                          <div className="bg-[#02040a] border border-white/5 rounded-xl p-5 border-l-2 border-l-cyan-500 shadow-inner">
                             <h4 className="text-[10px] font-bold text-slate-400 mb-2 uppercase tracking-widest">AI Insight</h4>
                             <p className="text-xs text-slate-300 leading-relaxed">
                               For massive scale, use Redis cluster for pub/sub to sync WebSocket connections across multiple gateway instances.
                             </p>
                          </div>
                       </div>
                       
                     </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
