import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Loader2, Terminal, Cpu, Activity, ShieldCheck, Hash, Code, ChevronRight } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';

interface Message {
  role: 'user' | 'model';
  text: string;
}

interface AiTutorTerminalProps {
  topicTitle: string;
  topicContent: string;
}

const QUICK_COMMANDS = [
  { cmd: "/explain_simply", desc: "Break down into simpler terms" },
  { cmd: "/interview_prep", desc: "Generate 3 potential interview questions" },
  { cmd: "/find_bottlenecks", desc: "Analyze failure points in this design" },
  { cmd: "/code_example", desc: "Show a relevant code snippet if applicable" }
];

export function AiTutorTerminal({ topicTitle, topicContent }: AiTutorTerminalProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [uptime, setUptime] = useState(0);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  useEffect(() => {
    const timer = setInterval(() => setUptime(u => u + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatUptime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSend = async (overrideInput?: string) => {
    const userMsg = overrideInput || input;
    if (!userMsg.trim()) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const gApiKey = process.env.GEMINI_API_KEY;
      if (!gApiKey) {
        setMessages(prev => [...prev, { role: 'model', text: '> **FATAL EXCEPTION:** `GEMINI_API_KEY` is undefined in the environment. System halted.' }]);
        setIsLoading(false);
        return;
      }
      
      const ai = new GoogleGenAI({ apiKey: gApiKey });
      
      const systemInstruction = `You are "Arch-OS", a highly advanced, snarky but brilliant engineering AI embedded in a systems design console.
      The user is viewing the module: ${topicTitle}.
      Context parameters:
      ${topicContent}
      
      Respond as if outputting to a developer console. Use Markdown. Keep it extremely precise, dense with information, yet highly readable. Use formatting (bolding, lists, code blocks). If they use a command like /explain_simply or /interview_prep, tailor the output perfectly to that command.`;

      const contents = messages.map(m => `${m.role === 'user' ? 'GUEST_USER' : 'ARCH_OS'}: ${m.text}`).join('\n');
      const nextContent = contents ? `${contents}\nGUEST_USER: ${userMsg}` : `GUEST_USER: ${userMsg}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: nextContent,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      if (response.text) {
        setMessages(prev => [...prev, { role: 'model', text: response.text ?? '' }]);
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'model', text: '> **NETWORK_ERR:** Uplink severed. Cannot reach neural core.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="w-full mt-24 mb-16 relative">
      {/* Container background & border */}
      <div className="rounded-xl overflow-hidden bg-[#0a0a0a] border border-[#2a2a2a] shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex flex-col h-[700px] font-mono">
        
        {/* IDE/Terminal Top Bar */}
        <div className="bg-[#111111] border-b border-[#2a2a2a] px-4 py-3 flex items-center justify-between select-none">
          <div className="flex items-center gap-4">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500/80 border border-red-500/50" />
              <div className="w-3 h-3 rounded-full bg-amber-500/80 border border-amber-500/50" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80 border border-emerald-500/50" />
            </div>
            <div className="hidden sm:flex items-center gap-2 text-xs text-[#666666]">
               <Terminal className="w-3.5 h-3.5" /> 
               <span>root@arch-os:~/{topicTitle.toLowerCase().replace(/\s+/g, '-')}</span>
            </div>
          </div>
          <div className="flex items-center gap-6 text-[10px] text-[#555555]">
            <span className="flex items-center gap-1.5"><Activity className="w-3 h-3 text-emerald-500" /> SYS_NORM</span>
            <span className="flex items-center gap-1.5"><Cpu className="w-3 h-3 text-blue-500" /> 12% USAGE</span>
            <span className="flex items-center gap-1.5"><ShieldCheck className="w-3 h-3 text-purple-500" /> SECURE</span>
            <span className="font-mono">UP: {formatUptime(uptime)}</span>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex flex-1 overflow-hidden">
          
          {/* Sidebar */}
          <div className="hidden md:flex w-64 bg-[#0d0d0d] border-r border-[#2a2a2a] flex-col p-4">
            <div className="mb-6">
              <div className="text-[10px] font-bold text-[#555555] uppercase tracking-widest mb-3">Active Context</div>
              <div className="flex items-start gap-2 text-sm text-[#e0e0e0]">
                <Hash className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span className="leading-tight">{topicTitle}</span>
              </div>
            </div>

            <div className="mb-6">
              <div className="text-[10px] font-bold text-[#555555] uppercase tracking-widest mb-3">Available Commands</div>
              <div className="space-y-2">
                {QUICK_COMMANDS.map((cmd, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(cmd.cmd)}
                    className="w-full text-left group"
                  >
                    <div className="flex items-center gap-2 text-xs font-mono text-[#888888] group-hover:text-emerald-400 transition-colors">
                      <ChevronRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      {cmd.cmd}
                    </div>
                    <div className="text-[10px] text-[#444444] pl-5 mt-0.5 group-hover:text-[#666]">{cmd.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-auto">
               <div className="text-[10px] text-[#444] py-2 border-t border-[#2a2a2a] flex flex-col gap-1">
                 <div>Arch-OS Kernel v4.2.0</div>
                 <div>Neural Engine Connected</div>
               </div>
            </div>
          </div>

          {/* Terminal Output */}
          <div className="flex-1 flex flex-col bg-[#050505] relative shadow-inner">
            <div className="flex-1 overflow-y-auto p-6" style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 transparent' }}>
              
              {messages.length === 0 ? (
                <div className="text-[#a0a0a0] max-w-2xl text-sm">
                  <div className="text-emerald-500 mb-4 font-bold flex items-center gap-2">
                    <Code className="w-5 h-5" /> ARCH-OS INITIALIZED
                  </div>
                  <p className="mb-2">System booted successfully. Module <span className="text-blue-400">'{topicTitle}'</span> loaded into memory.</p>
                  <p className="mb-6">I am your architectural copilot. Use the command sidebar or type natural language queries below to begin system analysis.</p>
                  
                  <div className="hidden md:block">
                    <div className="text-[#555] text-xs mb-2">--- Quick Help ---</div>
                    <ul className="text-xs space-y-1 text-[#777] list-disc list-inside">
                      <li>Type <span className="text-[#999]">any technical question</span> regarding the current architecture.</li>
                      <li>Click the quick commands on the left for standard operations.</li>
                      <li>Use <kbd className="bg-[#222] px-1 py-0.5 rounded border border-[#333]">Enter</kbd> to submit, <kbd className="bg-[#222] px-1 py-0.5 rounded border border-[#333]">Shift + Enter</kbd> for newline.</li>
                    </ul>
                  </div>
                  {/* Mobile Quick Commands */}
                  <div className="md:hidden mt-8">
                     <div className="text-[#555] text-xs mb-3 uppercase tracking-wider">Available Commands</div>
                     <div className="flex flex-wrap gap-2">
                       {QUICK_COMMANDS.map(c => (
                         <button key={c.cmd} onClick={() => handleSend(c.cmd)} className="px-3 py-1.5 bg-[#1a1a1a] border border-[#333] hover:border-emerald-500/50 hover:bg-[#222] text-emerald-400/80 rounded flex items-center gap-1.5 text-xs transition-colors">
                           <ChevronRight className="w-3 h-3" /> {c.cmd}
                         </button>
                       ))}
                     </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-6 pb-4 text-[13px]">
                  {messages.map((m, idx) => (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={idx} 
                      className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
                    >
                      <div className={`flex items-center gap-2 text-[10px] mb-1 font-bold tracking-widest uppercase ${m.role === 'user' ? 'text-blue-500' : 'text-emerald-500'}`}>
                        {m.role === 'user' ? 'guest_user' : 'arch_os'}
                      </div>
                      <div className={`max-w-[90%] md:max-w-[80%] ${
                        m.role === 'user' 
                          ? 'text-[#cccccc]' 
                          : 'text-[#e2e8f0]'
                      }`}>
                        {m.role === 'user' ? (
                          <div className="bg-[#111111] border border-[#2a2a2a] px-4 py-2 rounded-lg text-[13px] inline-block font-sans">
                            {m.text}
                          </div>
                        ) : (
                           <div className="markdown-body font-sans prose prose-invert prose-p:leading-relaxed prose-pre:bg-[#0d0d0d] prose-pre:border prose-pre:border-[#2a2a2a] prose-pre:-mx-2 md:prose-pre:-mx-4 prose-pre:rounded-lg prose-pre:shadow-lg prose-sm max-w-none">
                             <ReactMarkdown>{m.text}</ReactMarkdown>
                           </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                  
                  {isLoading && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-start mt-4">
                      <div className="text-emerald-500 text-[10px] mb-1 font-bold tracking-widest uppercase">arch_os</div>
                      <div className="flex items-center gap-3 text-[#666666] text-sm font-mono mt-1">
                        <Loader2 className="w-3 h-3 animate-spin text-emerald-500" /> 
                        <span className="animate-pulse">processing_query...</span>
                      </div>
                    </motion.div>
                  )}
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Form */}
            <div className="p-4 bg-[#0a0a0a] border-t border-[#2a2a2a] flex items-center gap-3 w-full">
              <span className="text-emerald-500 font-bold ml-2 animate-pulse">&gt;</span>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Execute command or ask question..."
                className="flex-1 bg-transparent border-none focus:ring-0 text-[#e0e0e0] placeholder-[#444] font-mono text-[13px] resize-none h-6 outline-none py-0.5 leading-relaxed"
                rows={1}
              />
              <button
                onClick={() => handleSend()}
                disabled={!input.trim() || isLoading}
                className="p-2 text-[#666] hover:text-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                title="Send command"
              >
                <div className="border border-current rounded p-1">
                  <Send className="w-3.5 h-3.5" />
                </div>
              </button>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  );
}

