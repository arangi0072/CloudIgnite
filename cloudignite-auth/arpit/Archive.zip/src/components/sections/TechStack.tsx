
import React from 'react';

const techs = [
  'Go', 'Django', 'Node.js', 'React', 'Docker', 'NGINX', 'Cassandra', 'PostgreSQL', 'Kong Gateway', 'Cloudflare Workers', 'Kubernetes', 'Redis', 'TypeScript', 'Python'
];

export const TechStack = () => {
  return (
    <section id="tech" className="py-24 border-y border-white/5 overflow-hidden">
      <div className="container mx-auto px-6 mb-12 text-center">
        <h2 className="text-xl font-bold uppercase tracking-[0.3em] text-muted-foreground">Core Technical Proficiencies</h2>
      </div>
      
      <div className="flex animate-scroll-x gap-16 whitespace-nowrap">
        {[...techs, ...techs].map((tech, idx) => (
          <div 
            key={idx} 
            className="text-3xl md:text-5xl font-headline font-black text-white/10 hover:text-primary transition-colors cursor-default"
          >
            {tech}
          </div>
        ))}
      </div>
    </section>
  );
};
